# Introduction

This project provides connectors for Kafka Connect to read and write data to Azure Search.

# Documentation

Documentation on the connector is hosted on Confluent's
[docs site](https://docs.confluent.io/current/connect/kafka-connect-azure-search/).

Source code is located in Confluent's
[docs repo](https://github.com/confluentinc/docs/tree/master/connect/kafka-connect-azure-search). If changes
are made to configuration options for the connector, be sure to generate the RST docs (as described
below) and open a PR against the docs repo to publish those changes!

# Configs

Documentation on the configurations for each connector can be automatically generated via Maven.

To generate documentation for the sink connector:
```bash
mvn -Pdocs exec:java@sink-config-docs
```

To generate documentation for the source connector:
```bash
mvn -Pdocs exec:java@source-config-docs
```

# Integration tests
## Retrieve credentials from Vault
```
vault kv get -field=creds v1/ci/kv/connect/azure_functions_it > credentials.json
export AZURE_AUTH_PATH=credentials.json
```
## Run integration tests
```
mvn clean integration-test
```
# Compatibility Matrix:

This connector has been tested against the following versions of Apache Kafka
and Azure Search:

|                          | AK 1.0             | AK 1.1        | AK 2.0        |
| ------------------------ | ------------------ | ------------- | ------------- |
| **Azure Search**         | NOT COMPATIBLE (1) | OK            | OK            |

1. The connector needs header support in Connect.

### Running Integration Tests
To run this integration, create a credentials file using these [instructions](https://github.com/Azure/azure-libraries-for-java/blob/master/AUTH.md)

Download the Azure CLI and run the following commands.
```
az login
az ad sp create-for-rbac --sdk-auth > <name_of_credentials_file>
```
Then in the configurations for this test, set the environment variable `AZURE_AUTH_PATH` to the
location of this file.